from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from .forms import UserRegisterForm, EnrollmentForm, FileUploadForm
from .models import Course, Enrollment, FileUpload

def register(request):
    if request.user.is_authenticated:
        return redirect('students:dashboard')
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, 'Registered successfully! You can now log in.')
            return redirect('students:login')
    else:
        form = UserRegisterForm()
    return render(request, 'students/register.html', {'form': form})

def user_login(request):
    if request.user.is_authenticated:
        return redirect('students:dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('students:dashboard')
        else:
            messages.error(request, 'Invalid credentials')
    else:
        form = AuthenticationForm()
    return render(request, 'students/login.html', {'form': form})

@login_required
def user_logout(request):
    logout(request)
    return redirect('students:login')

@login_required
def dashboard(request):
    courses = Course.objects.all()
    enrollments = Enrollment.objects.filter(student=request.user)
    uploaded_files = FileUpload.objects.filter(uploaded_by=request.user)
    return render(request, 'students/dashboard.html', {
        'courses': courses,
        'enrollments': enrollments,
        'uploaded_files': uploaded_files,
    })

@login_required
def enroll(request):
    if request.method == 'POST':
        form = EnrollmentForm(request.POST)
        if form.is_valid():
            course = form.cleaned_data['course']
            current_count = Enrollment.objects.filter(student=request.user).count()
            if current_count >= 5:
                messages.warning(request, 'You can enroll in a maximum of 5 courses.')
            else:
                Enrollment.objects.get_or_create(student=request.user, course=course)
                messages.success(request, 'Enrolled successfully!')
            return redirect('students:dashboard')
    else:
        form = EnrollmentForm()
    return render(request, 'students/enroll.html', {'form': form})

@login_required
def upload_file(request):
    if request.method == 'POST':
        form = FileUploadForm(request.POST, request.FILES)
        if form.is_valid():
            file_upload = form.save(commit=False)
            file_upload.uploaded_by = request.user
            file_upload.save()
            messages.success(request, 'File uploaded successfully!')
            return redirect('students:upload_file')
    else:
        form = FileUploadForm()
    uploaded_files = FileUpload.objects.filter(uploaded_by=request.user)
    return render(request, 'students/upload.html', {
        'form': form,
        'uploaded_files': uploaded_files,
    })

@login_required
def delete_file(request, file_id):
    file_obj = get_object_or_404(FileUpload, id=file_id)
    if request.user == file_obj.uploaded_by or request.user.is_staff:
        file_obj.file.delete()
        file_obj.delete()
        messages.success(request, 'File deleted successfully')
    else:
        messages.error(request, 'You do not have permission to delete this file')
    return redirect('students:upload_file')


@login_required
def delete_enrollment(request, enrollment_id):
    enrollment = get_object_or_404(Enrollment, id=enrollment_id, student=request.user)
    if request.method == 'POST':
        enrollment.delete()
    return redirect('students:dashboard')