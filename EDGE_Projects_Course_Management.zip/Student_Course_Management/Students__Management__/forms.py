from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Enrollment, Course, FileUpload

class UserRegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class EnrollmentForm(forms.Form):
    course = forms.ModelChoiceField(queryset=Course.objects.all(), label="Select Course")

class FileUploadForm(forms.ModelForm):
    class Meta:
        model = FileUpload
        fields = ['course', 'file']
