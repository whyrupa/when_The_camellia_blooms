# Django Student Course Management System

## Description
A web application allowing students to register, log in, enroll in courses, and upload/download course-related files. Admins can manage courses and view student data.

## Setup Instructions

### Prerequisites
- Python 3.8+
- pip
- virtualenv (optional but recommended)

### Installation

```bash
# Clone or download the project
cd path/to/project

# (Optional) Create and activate virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Apply migrations
python manage.py migrate

# Create superuser (for admin access)
python manage.py createsuperuser

# Run the development server
python manage.py runserver
```

### Login URLs
- Student registration: `/register/`
- Student login: `/login/`
- Admin panel: `/admin/`

### Notes
- Students can enroll in up to 5 courses.
- Only the file uploader or an admin can delete a file.
