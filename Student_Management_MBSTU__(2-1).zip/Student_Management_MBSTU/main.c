#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 100

// ================= STRUCTURE =================
struct Student {
    int id;
    char name[50];
    char department[50];
    char session[20];
    float cgpa;
    char phone[20];
};

// =============== GLOBAL VARIABLES =============
struct Student students[MAX];
int count = 0;

// =============== FUNCTION DECLARATIONS =============
void login();
void mainMenu();
void addStudent();
void displayStudents();
void searchStudent();
void updateStudent();
void deleteStudent();
void loadData();
void saveData();

// =============== LOGIN FUNCTION ===============
void login() {
    system("cls");
    char user[20], pass[20];
    int attempt = 0;

    while (attempt < 3) {
        printf("\n=====================================\n");
        printf("   MBSTU STUDENT MANAGEMENT SYSTEM   \n");
        printf("=====================================\n");
        printf("\nUsername: ");
        scanf("%s", user);
        printf("Password: ");
        scanf("%s", pass);

        if (strcmp(user, "rupadas") == 0 && strcmp(pass, "12345") == 0) {
            printf("\nLogin Successful! Welcome, %s.\n", user);
            system("pause");
            loadData(); // load existing records from file
            mainMenu();
            return;
        } else {
            printf("\nInvalid credentials! Try again.\n");
            attempt++;
            system("pause");
            system("cls");
        }
    }
    printf("\nToo many failed attempts. Exiting...\n");
    exit(0);
}

// =============== MAIN MENU ===============
void mainMenu() {
    int choice;
    while (1) {
        system("cls");
        printf("\n=====================================\n");
        printf("   MBSTU STUDENT MANAGEMENT SYSTEM   \n");
        printf("=====================================\n");
        printf("1. Add Student\n");
        printf("2. Display All Students\n");
        printf("3. Search Student\n");
        printf("4. Update Student\n");
        printf("5. Delete Student\n");
        printf("6. Exit\n");
        printf("=====================================\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: addStudent(); break;
            case 2: displayStudents(); break;
            case 3: searchStudent(); break;
            case 4: updateStudent(); break;
            case 5: deleteStudent(); break;
            case 6:
                saveData(); // save before exit
                printf("\nThank you for using MBSTU SMS!\n");
                exit(0);
            default:
                printf("\nInvalid choice! Try again.\n");
                system("pause");
        }
    }
}

// =============== ADD STUDENT ===============
void addStudent() {
    system("cls");
    printf("\n=========== ADD NEW STUDENT ===========\n");

    printf("Enter Student ID: ");
    scanf("%d", &students[count].id);

    printf("Enter Name: ");
    getchar();
    gets(students[count].name);

    printf("Enter Department: ");
    gets(students[count].department);

    printf("Enter Session: ");
    gets(students[count].session);

    printf("Enter CGPA: ");
    scanf("%f", &students[count].cgpa);

    printf("Enter Phone: ");
    scanf("%s", students[count].phone);

    count++;
    saveData(); // save immediately
    printf("\nStudent added successfully!\n");
    system("pause");
}

// =============== DISPLAY STUDENTS ===============
void displayStudents() {
    system("cls");
    printf("\n=========== ALL STUDENT RECORDS ===========\n");

    if (count == 0) {
        printf("\nNo records found!\n");
    } else {
        printf("\n%-5s %-20s %-15s %-12s %-8s %-15s\n",
               "ID", "Name", "Department", "Session", "CGPA", "Phone");
        printf("-------------------------------------------------------------------------------\n");

        for (int i = 0; i < count; i++) {
            printf("%-5d %-20s %-15s %-12s %-8.2f %-15s\n",
                   students[i].id, students[i].name, students[i].department,
                   students[i].session, students[i].cgpa, students[i].phone);
        }
    }
    printf("\n");
    system("pause");
}

// =============== SEARCH STUDENT ===============
void searchStudent() {
    system("cls");
    int id, found = 0;
    printf("\n=========== SEARCH STUDENT ===========\n");
    printf("Enter Student ID to search: ");
    scanf("%d", &id);

    printf("\n%-5s %-20s %-15s %-12s %-8s %-15s\n",
           "ID", "Name", "Department", "Session", "CGPA", "Phone");
    printf("-------------------------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        if (students[i].id == id) {
            printf("%-5d %-20s %-15s %-12s %-8.2f %-15s\n",
                   students[i].id, students[i].name, students[i].department,
                   students[i].session, students[i].cgpa, students[i].phone);
            found = 1;
            break;
        }
    }

    if (!found)
        printf("\nNo student found with ID %d.\n", id);

    system("pause");
}

// =============== UPDATE STUDENT ===============
void updateStudent() {
    system("cls");
    int id, found = 0;
    printf("\n=========== UPDATE STUDENT ===========\n");
    printf("Enter Student ID to update: ");
    scanf("%d", &id);

    for (int i = 0; i < count; i++) {
        if (students[i].id == id) {
            printf("\nEnter new details:\n");

            printf("Name: ");
            getchar();
            gets(students[i].name);

            printf("Department: ");
            gets(students[i].department);

            printf("Session: ");
            gets(students[i].session);

            printf("CGPA: ");
            scanf("%f", &students[i].cgpa);

            printf("Phone: ");
            scanf("%s", students[i].phone);

            saveData();
            printf("\nRecord updated successfully!\n");
            found = 1;
            break;
        }
    }

    if (!found)
        printf("\nNo student found with ID %d.\n", id);

    system("pause");
}

// =============== DELETE STUDENT ===============
void deleteStudent() {
    system("cls");
    int id, found = 0;
    char dept[50];
    printf("\n=========== DELETE STUDENT ===========\n");
    printf("Enter Student ID: ");
    scanf("%d", &id);
    printf("Enter Department: ");
    getchar();
    gets(dept);

    for (int i = 0; i < count; i++) {
        if (students[i].id == id && strcmp(students[i].department, dept) == 0) {
            for (int j = i; j < count - 1; j++) {
                students[j] = students[j + 1];
            }
            count--;
            saveData();
            printf("\nRecord deleted successfully!\n");
            found = 1;
            break;
        }
    }

    if (!found)
        printf("\nNo matching record found!\n");

    system("pause");
}

// =============== FILE HANDLING FUNCTIONS ===============
void loadData() {
    FILE *fp = fopen("students.txt", "r");
    if (fp == NULL) return; // no file yet

    count = 0;
    while (fscanf(fp, "%d,%[^,],%[^,],%[^,],%f,%s\n",
                  &students[count].id,
                  students[count].name,
                  students[count].department,
                  students[count].session,
                  &students[count].cgpa,
                  students[count].phone) == 6) {
        count++;
    }
    fclose(fp);
}

void saveData() {
    FILE *fp = fopen("students.txt", "w");
    if (fp == NULL) {
        printf("\nError saving data!\n");
        return;
    }

    for (int i = 0; i < count; i++) {
        fprintf(fp, "%d,%s,%s,%s,%.2f,%s\n",
                students[i].id,
                students[i].name,
                students[i].department,
                students[i].session,
                students[i].cgpa,
                students[i].phone);
    }
    fclose(fp);
}

// =============== MAIN FUNCTION ===============
int main() {
    login();
    return 0;
}
